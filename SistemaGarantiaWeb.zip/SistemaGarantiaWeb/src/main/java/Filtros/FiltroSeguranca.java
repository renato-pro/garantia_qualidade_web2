package Filtros;

import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter("/*") // Remova o // para ativar a segurança
public class FiltroSeguranca implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession sessao = req.getSession();

        String urlAcessada = req.getRequestURI();
        Object usuarioLogado = sessao.getAttribute("usuarioLogado");

        // 1. Verifica se o usuário NÃO está logado e tenta acessar algo restrito
        if (usuarioLogado == null && 
            !urlAcessada.contains("login.jsp") && 
            !urlAcessada.contains("LoginServlet") && 
            !urlAcessada.contains("esqueci-senha.jsp") && 
            !urlAcessada.contains("RecuperarSenhaServlet")) { 
            
            res.sendRedirect(req.getContextPath() + "/login.jsp");
        } else {
            // 2. ESSA LINHA É A MAIS IMPORTANTE: Ela manda o servidor continuar para a página!
            // Se ela não existir, a tela fica branca para sempre.
            chain.doFilter(request, response);
        }
    }
}