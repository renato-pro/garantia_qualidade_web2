package br.com.senac.controller;

import br.com.senac.model.Cliente;
import br.com.senac.service.ClienteService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ClienteServlet", urlPatterns = {"/cadastrar-cliente"})
public class ClientServlet extends HttpServlet {

    private final ClienteService clienteService = new ClienteService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Cliente cliente = new Cliente();
        cliente.setNome(request.getParameter("nome"));
        cliente.setEmail(request.getParameter("email"));
        cliente.setEndereco(request.getParameter("endereco"));
        cliente.setComplemento(request.getParameter("complemento"));
        cliente.setCidade(request.getParameter("cidade"));
        cliente.setEstado(request.getParameter("estado"));
        cliente.setContato(request.getParameter("contato"));
        cliente.setTelefone(request.getParameter("telefone"));

        try {
            clienteService.cadastrarCliente(cliente);
            response.sendRedirect("sucesso.jsp");
        } catch (Exception e) {
            request.setAttribute("mensagemErro", e.getMessage());
            request.getRequestDispatcher("form-cliente.jsp").forward(request, response);
        }
    }
}