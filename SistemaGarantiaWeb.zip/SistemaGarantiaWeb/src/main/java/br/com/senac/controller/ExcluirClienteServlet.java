package br.com.senac.servlet; // Ajuste conforme seu pacote

import br.com.senac.data.ClienteDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/excluir-cliente")
public class ExcluirClienteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Pega o ID enviado pelo link da tabela
        String idParam = request.getParameter("id");
        
        if (idParam != null) {
            int id = Integer.parseInt(idParam);
            ClienteDAO dao = new ClienteDAO();
            
            try {
                // 2. Chama o método excluir que você já tem no DAO
                dao.excluir(id);
                
                // 3. Redireciona de volta para a lista atualizada
                response.sendRedirect("listar-clientes"); 
                
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("listar-clientes?erro=falhaAoExcluir");
            }
        }
    }
}