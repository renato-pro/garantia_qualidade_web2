package br.com.senac.controller;

import br.com.senac.model.Cliente;
import br.com.senac.service.ClienteService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ListarClientesServlet", urlPatterns = {"/listar-clientes"})
public class ListarClientesServlet extends HttpServlet {

    private final ClienteService clienteService = new ClienteService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Chama o Service para buscar os dados do DAO
        List<Cliente> lista = clienteService.listarClientes();
        
        // 2. Coloca a lista no request para o JSP acessar
        request.setAttribute("listaClientes", lista);
        
        // 3. Encaminha para a página de visualização
        request.getRequestDispatcher("lista-clientes.jsp").forward(request, response);
    }
}