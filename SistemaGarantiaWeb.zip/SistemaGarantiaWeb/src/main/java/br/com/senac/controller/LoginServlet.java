package br.com.senac.controller;

import br.com.senac.data.ClienteDAO;
import br.com.senac.model.Cliente;
import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Captura os dados do formulário
        String usuarioInformado = request.getParameter("usuario");
        String senhaInformada = request.getParameter("senha");

        try {
            // 2. Instancia o DAO
            ClienteDAO dao = new ClienteDAO();
            
            // AJUSTE: Passando a senha direta, sem MD5, pois seu banco está em texto simples
            Cliente usuarioLogado = dao.autenticar(usuarioInformado, senhaInformada);

            if (usuarioLogado != null) {
    HttpSession sessao = request.getSession();
    
    // Além de salvar o objeto todo, vamos salvar o nome separadamente para facilitar
    sessao.setAttribute("usuarioLogado", usuarioLogado);
    sessao.setAttribute("nomeUsuario", usuarioLogado.getNome()); 
    
    response.sendRedirect("index.jsp");
} else {
                // Falha: Dados não batem com a tabela
                request.setAttribute("msgErro", "Usuário ou senha inválidos!");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            // Erro de conexão ou SQL
            e.printStackTrace();
            request.setAttribute("msgErro", "Erro ao conectar ao banco de dados: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}