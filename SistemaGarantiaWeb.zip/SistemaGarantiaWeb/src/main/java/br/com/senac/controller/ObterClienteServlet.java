package br.com.senac.servlet;

import br.com.senac.data.ClienteDAO;
import br.com.senac.model.Cliente;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/obter-cliente")
public class ObterClienteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Captura o ID do link da tabela
        int id = Integer.parseInt(request.getParameter("id"));
        ClienteDAO dao = new ClienteDAO();
        
        try {
            // 2. Busca o cliente no banco usando o ID
            Cliente clienteEncontrado = dao.getCliente(id);
            
            // 3. Coloca o objeto cliente na "mochila" (request) para o JSP usar
            request.setAttribute("cliente", clienteEncontrado);
            
            // 4. Encaminha para o formulário de cadastro/edição
            request.getRequestDispatcher("form-cliente.jsp").forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("listar-clientes?erro=buscaFalhou");
        }
    }
}