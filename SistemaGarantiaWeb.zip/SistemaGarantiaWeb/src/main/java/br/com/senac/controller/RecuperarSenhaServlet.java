package br.com.senac.controller;

import br.com.senac.data.UsuarioDAO; // Importar UsuarioDAO
import br.com.senac.model.Usuario;   // Importar Usuario
import br.com.senac.service.EmailService;
import br.com.senac.data.Criptografia;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "RecuperarSenhaServlet", urlPatterns = {"/RecuperarSenhaServlet"})
public class RecuperarSenhaServlet extends HttpServlet {

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    // 1. Pega o "login" que o usuário digitou na tela
    String loginInformado = request.getParameter("usuario"); 
    System.out.println("Login recebido da tela: " + loginInformado);

    UsuarioDAO dao = new UsuarioDAO();
    EmailService emailService = new EmailService();

    // 2. Busca o usuário pelo LOGIN
    Usuario usuario = dao.buscarPorLogin(loginInformado);

    if (usuario != null) {
        // 3. Gera a nova senha
        String novaSenhaTextoPuro = String.valueOf((int)(Math.random() * 900000) + 100000);
        String senhaCriptografada = Criptografia.converter(novaSenhaTextoPuro);
        
        // 4. Atualiza a senha no banco (usando o ID que o buscarPorLogin trouxe)
        boolean atualizado = dao.atualizarSenha(usuario.getId(), senhaCriptografada);

        if (atualizado) {
            // 5. ENVIAMOS PARA O E-MAIL QUE ESTÁ CADASTRADO NO BANCO!
            // Note que usamos usuario.getEmail() que foi preenchido no buscarPorLogin
            emailService.enviarEmailRecuperacao(usuario.getEmail(), novaSenhaTextoPuro);
            
            response.sendRedirect("sucesso.jsp?msg=Sucesso! Senha enviada para o e-mail cadastrado.");
        } else {
            response.sendRedirect("esqueci-senha.jsp?erro=Erro ao atualizar banco.");
        }
    } else {
        System.out.println("FALHA: O login '" + loginInformado + "' nao existe.");
        response.sendRedirect("esqueci-senha.jsp?erro=Usuario nao encontrado.");
    }
}
}