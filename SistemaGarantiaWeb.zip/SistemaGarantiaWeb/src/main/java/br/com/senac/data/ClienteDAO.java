package br.com.senac.data;

import br.com.senac.model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Camada de Acesso a Dados (DAO)
 * Responsabilidade Única: Executar operações SQL no banco de dados.
 * @author Renato Melo - Refatorado para SOLID
 */
public class ClienteDAO {

    private final Conexao conexao;

    public ClienteDAO() {
        this.conexao = new Conexao();
    }

    /**
     * Insere um novo cliente no banco de dados.
     * Refatoração: Uso de try-with-resources para garantir o fechamento da conexão.
     */
    public void inserir(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO cliente(nome, endereco, complemento, cidade, estado, contato, telefone, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = this.conexao.conectar(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            preencherStatement(stmt, cliente);
            stmt.execute();
        } 
    }

    /**
     * Edita um cliente existente.
     */
    public void editar(Cliente cliente) throws SQLException {
        String sql = "UPDATE cliente SET nome=?, endereco=?, complemento=?, cidade=?, estado=?, contato=?, telefone=?, email=? WHERE id=?";
        
        try (Connection conn = this.conexao.conectar(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            preencherStatement(stmt, cliente);
            stmt.setInt(9, cliente.getId());
            stmt.executeUpdate();
        }
    }

    /**
     * Exclui um cliente pelo ID.
     */
    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM cliente WHERE id = ?";
        
        try (Connection conn = this.conexao.conectar(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            stmt.execute();
        }
    }

    /**
     * Busca um cliente específico pelo ID.
     */
    public Cliente getCliente(int id) throws SQLException {
        String sql = "SELECT * FROM cliente WHERE id = ?";
        
        try (Connection conn = this.conexao.conectar(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearResultSetParaCliente(rs);
                }
            }
        }
        return null;
    }

    /**
     * Lista clientes filtrando por parte do nome.
     */
    public List<Cliente> listarPorNome(String nome) throws SQLException {
        String sql = "SELECT * FROM cliente WHERE nome LIKE ?";
        List<Cliente> lista = new ArrayList<>();

        try (Connection conn = this.conexao.conectar(); 
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, "%" + nome + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearResultSetParaCliente(rs));
                }
            }
        }
        return lista;
    }
    
    /**
 * Retorna todos os clientes cadastrados.
 */
public List<Cliente> listarTodos() throws SQLException {
    String sql = "SELECT * FROM cliente";
    List<Cliente> lista = new ArrayList<>();

    try (Connection conn = this.conexao.conectar(); 
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {
        
        while (rs.next()) {
            lista.add(mapearResultSetParaCliente(rs));
        }
    }
    return lista;
}

    // --- MÉTODOS AUXILIARES (Refatoração para evitar repetição de código) ---

    private void preencherStatement(PreparedStatement stmt, Cliente cliente) throws SQLException {
        stmt.setString(1, cliente.getNome());
        stmt.setString(2, cliente.getEndereco());
        stmt.setString(3, cliente.getComplemento());
        stmt.setString(4, cliente.getCidade());
        stmt.setString(5, cliente.getEstado());
        stmt.setString(6, cliente.getContato());
        stmt.setString(7, cliente.getTelefone());
        stmt.setString(8, cliente.getEmail());
    }

    private Cliente mapearResultSetParaCliente(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setId(rs.getInt("id"));
        cliente.setNome(rs.getString("nome"));
        cliente.setEndereco(rs.getString("endereco"));
        cliente.setComplemento(rs.getString("complemento"));
        cliente.setCidade(rs.getString("cidade"));
        cliente.setEstado(rs.getString("estado"));
        cliente.setContato(rs.getString("contato"));
        cliente.setTelefone(rs.getString("telefone"));
        cliente.setEmail(rs.getString("email"));
        return cliente;
    }
}