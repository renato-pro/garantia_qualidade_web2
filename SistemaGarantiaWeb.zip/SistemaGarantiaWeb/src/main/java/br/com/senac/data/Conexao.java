package br.com.senac.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    public static Connection getConexao() {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        // Verifique se o nome após a porta 3306/ está correto!
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/garantia_qualidade", "root", "Password2025@");
    } catch (Exception e) {
        // ESSA LINHA ABAIXO É A CHAVE:
        System.out.println("--- ERRO DE CONEXÃO REVELADO: " + e.getMessage());
        e.printStackTrace(); 
        return null;
    }
    }
}