package br.com.senac.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Renato Melo - Ajustado para Web/SOLID
 */
public class Conexao {

    // Configurações de conexão centralizadas
    private static final String URL = "jdbc:mysql://localhost/garantia_qualidade";
    private static final String USER = "adm";
    private static final String PASS = "Password2025@";

    /**
     * Estabelece conexão com o banco de dados.
     * Alteramos para lançar SQLException (throws) para que o Service/DAO 
     * saiba se houve um erro e possa tratar adequadamente.
     */
    public Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASS);
        } catch (ClassNotFoundException ex) {
            throw new SQLException("Erro: Driver JDBC não encontrado! " + ex.getMessage());
        }
    }

    /**
     * Fecha a conexão de forma segura.
     */
    public void desconectar(Connection conn) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException ex) {
            // Em log ou console apenas para depuração
            System.err.println("Erro ao fechar conexão: " + ex.getMessage());
        }
    }
}