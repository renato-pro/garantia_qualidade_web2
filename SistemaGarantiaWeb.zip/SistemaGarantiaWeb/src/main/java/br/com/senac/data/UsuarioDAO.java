package br.com.senac.data;

import br.com.senac.model.Usuario;
import java.sql.*;

public class UsuarioDAO {
    public Usuario buscarPorEmail(String email) {
        String sql = "SELECT * FROM usuario WHERE email = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario u = new Usuario();
                    u.setId(rs.getInt("id"));
                    u.setEmail(rs.getString("email"));
                    return u;
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean atualizarSenha(int id, String novaSenha) {
        String sql = "UPDATE usuario SET senha = ? WHERE id = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, novaSenha);
            stmt.setInt(2, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
    
    
    public Usuario buscarPorLogin(String login) {
    // Mudamos a consulta para olhar a coluna 'login'
    String sql = "SELECT * FROM usuario WHERE login = ?"; 
    try (Connection conn = Conexao.getConexao();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        
        stmt.setString(1, login);
        
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setLogin(rs.getString("login")); // Agora pegamos o login
                u.setSenha(rs.getString("senha"));
                u.setEmail(rs.getString("email")); // Mantemos o e-mail para o envio posterior
                return u;
            }
        }
    } catch (SQLException e) { 
        e.printStackTrace(); 
    }
    return null;
}
}