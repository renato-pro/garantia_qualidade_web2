package br.com.senac.service;

import br.com.senac.data.ClienteDAO;
import br.com.senac.model.Cliente;
import java.sql.SQLException;
import java.util.List;

/**
 * Camada de Negócio (Service)
 * Responsabilidade: Validar regras de negócio antes de acessar o banco.
 * @author Renato Melo
 */
public class ClienteService {

    private final ClienteDAO clienteDAO;

    public ClienteService() {
        this.clienteDAO = new ClienteDAO();
    }

    /**
     * Regra de Negócio: Cálculo de Garantia Estendida
     * Até 12 meses: 10% do valor do produto
     * Acima de 12 meses: 20% do valor do produto
     */
    public double calcularValorGarantia(double valorProduto, int meses) {
        if (valorProduto <= 0) {
            return 0;
        }
        if (meses <= 12) {
            return valorProduto * 0.10;
        } else {
            return valorProduto * 0.20;
        }
    }

    /**
     * Regra de Negócio: Salvar cliente apenas se os dados forem válidos.
     */
    public void cadastrarCliente(Cliente cliente) throws Exception {
        // Validação Simples
        if (cliente.getNome() == null || cliente.getNome().trim().isEmpty()) {
            throw new Exception("O nome do cliente é obrigatório.");
        }
        
        if (cliente.getEmail() == null || !cliente.getEmail().contains("@")) {
            throw new Exception("E-mail inválido.");
        }

        // Se passar pelas validações, chama o DAO
        try {
            clienteDAO.inserir(cliente);
        } catch (SQLException e) {
            throw new Exception("Erro técnico ao salvar no banco: " + e.getMessage());
        }
    }

    public List<Cliente> buscarPorNome(String nome) throws Exception {
        try {
            return clienteDAO.listarPorNome(nome);
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar clientes: " + e.getMessage());
        }
    }
    
    public List<Cliente> listarClientes() {
        try {
            return clienteDAO.listarTodos();
        } catch (Exception e) {
            throw new RuntimeException("Erro ao carregar lista de clientes", e);
        }
    }

    public void removerCliente(int id) throws Exception {
        try {
            clienteDAO.excluir(id);
        } catch (SQLException e) {
            throw new Exception("Não foi possível excluir o cliente.");
        }
    }
}