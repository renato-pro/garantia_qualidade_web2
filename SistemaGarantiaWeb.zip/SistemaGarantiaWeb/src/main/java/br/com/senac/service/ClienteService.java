package br.com.senac.service;

import br.com.senac.data.ClienteDAO;
import br.com.senac.model.Cliente;
import java.sql.SQLException;
import java.util.List;

/**
 * Camada de Negócio (Service)
 * Responsabilidade: Validar regras de negócio antes de acessar o banco.
 * @author Renato Melo
 */
public class ClienteService {

    private final ClienteDAO clienteDAO;

    public ClienteService() {
        this.clienteDAO = new ClienteDAO();
    }

    /**
     * Regra de Negócio: Salvar cliente apenas se os dados forem válidos.
     */
    public void cadastrarCliente(Cliente cliente) throws Exception {
        // Validação Simples (Exemplo de SRP)
        if (cliente.getNome() == null || cliente.getNome().trim().isEmpty()) {
            throw new Exception("O nome do cliente é obrigatório.");
        }
        
        if (!cliente.getEmail().contains("@")) {
            throw new Exception("E-mail inválido.");
        }

        // Se passar pelas validações, chama o DAO
        try {
            clienteDAO.inserir(cliente);
        } catch (SQLException e) {
            throw new Exception("Erro técnico ao salvar no banco: " + e.getMessage());
        }
    }

    public List<Cliente> buscarPorNome(String nome) throws Exception {
        try {
            return clienteDAO.listarPorNome(nome);
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar clientes: " + e.getMessage());
        }
    }
    
    public List<Cliente> listarClientes() {
    try {
        return clienteDAO.listarTodos(); // Chama o método que você já tem no DAO
    } catch (Exception e) {
        throw new RuntimeException("Erro ao carregar lista de clientes", e);
    }
}

    public void removerCliente(int id) throws Exception {
        try {
            clienteDAO.excluir(id);
        } catch (SQLException e) {
            throw new Exception("Não foi possível excluir o cliente.");
        }
    }
}