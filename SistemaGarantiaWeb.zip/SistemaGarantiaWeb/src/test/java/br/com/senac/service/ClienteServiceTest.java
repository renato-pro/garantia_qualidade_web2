package br.com.senac.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class ClienteServiceTest {

    @Test
    @DisplayName("Deve calcular 10% de garantia para prazos de até 12 meses")
    public void deveCalcularGarantiaDeDezPorCento() {
        ClienteService service = new ClienteService();
        double valorProduto = 1000.0;
        int meses = 12;
        
        double resultado = service.calcularValorGarantia(valorProduto, meses);
        
        // Exibe o cálculo no console
        System.out.println("--- Teste 10% ---");
        System.out.println("Valor Produto: " + valorProduto);
        System.out.println("Meses: " + meses);
        System.out.println("Resultado calculado: " + resultado);
        
        assertEquals(100.0, resultado, 0.001);
    }

    @Test
    @DisplayName("Deve calcular 20% de garantia para prazos acima de 12 meses")
    public void deveCalcularGarantiaDeVintePorCento() {
        ClienteService service = new ClienteService();
        double valorProduto = 1000.0;
        int meses = 24;
        
        double resultado = service.calcularValorGarantia(valorProduto, meses);
        
        // Exibe o cálculo no console
        System.out.println("--- Teste 20% ---");
        System.out.println("Valor Produto: " + valorProduto);
        System.out.println("Meses: " + meses);
        System.out.println("Resultado calculado: " + resultado);
        
        assertEquals(200.0, resultado, 0.001);
    }
}